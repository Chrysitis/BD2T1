const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const db = require('./queries')
const port = 3000

app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)

app.get('/', (request, response) => {
  response.json({ info: 'Node.js, Express, and Postgres API' })
})

//app.get('/users', db.getUsers)
//app.get('/users/:id', db.getUserById)
//app.post('/users', db.createUser)
//app.put('/users/:id', db.updateUser)
//app.delete('/users/:id', db.deleteUser)
// ---
app.get('/Categorias', db.getCategories)
app.post('/Categorias', db.createCategory)
app.put('/Categorias/:id', db.updateCategory)
app.delete('/Categorias/:id', db.deleteCategory)
// ---
app.get('/Productos', db.getProducts)
app.post('/Productos', db.createProduct)
app.put('/Productos/:id', db.updateProduct)
app.delete('/Productos/:id', db.deleteProduct)
// --
app.get('/Locales', db.getLocales)
app.post('/Locales', db.createLocales)
app.put('/Locales/:id', db.updateLocales)
app.delete('/Locales/:id', db.deleteLocales)
// --
app.get('/Generos', db.getGeneros)
app.post('/Generos', db.createGeneros)
app.put('/Generos/:id', db.updateGeneros)
app.delete('/Generos/:id', db.deleteGeneros)
// --
app.get('/Empleados', db.getEmpleados)
app.post('/Empleados', db.createEmpleados)
app.put('/Empleados/:id', db.updateEmpleados)
app.delete('/Empleados/:id', db.deleteEmpleados)
// --
app.get('/LocalesEmpleados', db.getLocalesEmpleados)
app.post('/LocalesEmpleados', db.createLocalesEmpleados)
// --
app.get('/LocalesProductos', db.getLocalesProductos)
app.post('/LocalesProductos', db.createLocalesProductos)
// --
app.listen(port, () => {
  console.log(`App running on port ${port}.`)
})
