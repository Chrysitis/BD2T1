const Pool = require('pg').Pool
const pool = new Pool({
  user: 'litki',
  host: 'localhost',
  database: 'rfapi',
  password: 'test',
  port: 5432,
})



// ------------------------------------------------------------

// ***** Categorias *****
const getCategories = (request, response) => {
  pool.query('SELECT * FROM Categorias  ORDER BY IDcategoria ASC', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createCategory = (request, response) => {
  const {categoria} = request.body

  pool.query('INSERT INTO Categorias (category) VALUES ($1) RETURNING IDcategoria', [categoria], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`Category added with ID: ${results.rows[0].IDcategoria}`)
  })
}

const updateCategory = (request, response) => {
  const idCategory = parseInt(request.params.id)
  const {categoria} = request.body

  pool.query(
    'UPDATE Categorias SET category = $1 WHERE IDcategoria = $2', [categoria, idCategory], (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`Category modified with ID: ${idCategory}`)
    }
  )
}

const deleteCategory = (request, response) => {
  const idCat = parseInt(request.params.id)

  pool.query('DELETE FROM Categorias WHERE IDcategoria = $1', [idCat], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`Category deleted with ID: ${idCat}`)
  })
}
// ***** Productos *****
const getProducts = (request, response) => {
  pool.query('SELECT * FROM Productos  ORDER BY IDproducto ASC', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createProduct = (request, response) => {
  const {idCategoriaP, productoP, cantProductoP, precioP} = request.body

  pool.query('INSERT INTO Productos (IDcategoria, producto, cantProducto, precio) VALUES ($1, $2, $3, $4)', [idCategoriaP, productoP, cantProductoP, precioP], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`Product added satisfactory.`) //${result.insertId}`)
  })
}

const updateProduct = (request, response) => {
  const idProduct = parseInt(request.params.id)
  const {idCategoriaP, productoP, cantProductoP, precioP} = request.body

  pool.query(
    'UPDATE Productos SET IDcategoria = $1, producto = $2, cantProducto = $3, precio = $4 WHERE IDproducto = $5',
    [idCategoriaP, productoP, cantProductoP, precioP, idProduct],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`Product modified with ID: ${idProduct}`)
    }
  )
}

const deleteProduct = (request, response) => {
  const idProduct = parseInt(request.params.id)

  pool.query('DELETE FROM Productos WHERE IDproducto = $1', [idProduct], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`Product deleted with ID: ${idProduct}`)
  })
}
// ***** Locales *****

const getLocales =(request, response) => {
  pool.query('SELECT * FROM Locales', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createLocales= (request, response) => {
  const {nombreP, ubicacionP, telefonoP} = request.body

  pool.query('INSERT INTO Locales(nombre, ubicacion, telefono) VALUES ($1,$2,$3)', [nombreP, ubicacionP, telefonoP], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`Local added satisfactory.`)
  })
}

const updateLocales = (request, response) => {
  const IDlocalP= parseInt(request.params.id)
  const {nombreP, ubicacionP, telefonoP} = request.body

  pool.query(
    'UPDATE Locales SET nombre = $1, ubicacion = $2, telefono = $3 WHERE IDlocal = $4',
    [nombreP, ubicacionP, telefonoP, IDlocalP],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`User modified with ID: ${IDlocalP}`)
    }
  )
}

const deleteLocales = (request, response) => {
  const IDlocal= parseInt(request.params.id)

  pool.query('DELETE FROM Locales WHERE IDlocal = $1', [IDlocal], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`User deleted with ID: ${IDlocal}`)
  })
}
// ***** Generos *****
const getGeneros =(request, response) => {
  pool.query('SELECT * FROM Generos', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}
const createGeneros = (request, response) => {
  const {generoP} = request.body

  pool.query('INSERT INTO Generos (genero) VALUES ($1)', [generoP], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`Gender added successfully.`)
  })
}

const updateGeneros = (request, response) => {
  const IDgenero = parseInt(request.params.id)
  const {generoP} = request.body

  pool.query(
    'UPDATE Generos SET genero = $1, WHERE IDgenero = $2',
    [generoP, IDgenero],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`Gender modified with ID: ${IDgenero}`)
    }
  )
}

const deleteGeneros = (request, response) => {
  const IDgeneroP = parseInt(request.params.id)

  pool.query('DELETE FROM Generos WHERE IDgenero = $1', [IDgeneroP], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`Gender deleted with ID: ${IDgeneroP}`)
  })
}

// ***** Empleados *****

const getEmpleados =(request, response) => {
  pool.query('SELECT * FROM Empleados', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createEmpleados = (request, response) => {
  const {IDgeneroP, nombreP, apellidoP, salarioP} = request.body

  pool.query('INSERT INTO Empleados (IDgenero, nombre, apellido, salario) VALUES ($1,$2,$3,$4)', [IDgeneroP, nombreP, apellidoP, salarioP], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`Employee added successfully.`)
  })
}

const updateEmpleados = (request, response) => {
  const IDempleado = parseInt(request.params.id)
  const {IDgeneroP, nombreP, apellidoP , salarioP} = request.body

  pool.query(
    'UPDATE Empleados SET IDgenero = $1, nombre = $2, apellido = $3, salario = $4 WHERE IDempleado = $5',
    [IDgeneroP, nombreP, apellidoP, salarioP, IDempleado],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`User modified with ID: ${IDempleado}`)
    }
  )
}

const deleteEmpleados = (request, response) => {
  const IDempleado = parseInt(request.params.id)

  pool.query('DELETE FROM Empleados WHERE IDempleado = $1', [IDempleado], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`User deleted with ID: ${IDempleado}`)
  })
}

// ***** LocalesEmpleados *****

const getLocalesEmpleados =(request, response) => {
  pool.query('SELECT * FROM LocalesEmpleados', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createLocalesEmpleados= (request, response) => {
  const {IDempleadoP, IDLocalP} = request.body

  pool.query('INSERT INTO LocalesEmpleados (IDempleado, IDlocal) VALUES ($1, $2)', [IDempleadoP, IDLocalP], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`Addition successfull.`)
  })
}
// ***** LocalesProductos *****
const getLocalesProductos =(request, response) => {
  pool.query('SELECT * FROM ProductosLocales', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createLocalesProductos = (request, response) => {
  const {IDproductoP, IDLocalP} = request.body

  pool.query('INSERT INTO ProductosLocales(IDproducto, IDLocal) VALUES ($1, $2)', [IDproductoP, IDLocalP], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`Addition successfull.`)
  })
}

// ***** *****
// ------------------------------------------------------------

const getUsers = (request, response) => {
  pool.query('SELECT * FROM Users ORDER BY id ASC', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const getUserById = (request, response) => {
const id = parseInt(request.params.id)

  pool.query('SELECT * FROM Users WHERE id = $1', [id], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createUser = (request, response) => {
  const { name, email } = request.body

    pool.query('INSERT INTO Users (name, email) VALUES ($1, $2) RETURNING id', [name, email], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`User added with ID: ${results.rows[0].id}`)
  })
}

const updateUser = (request, response) => {
  const id = parseInt(request.params.id)
  const { name, email } = request.body

  pool.query(
    'UPDATE Users SET name = $1, email = $2 WHERE id = $3',
    [name, email, id],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`User modified with ID: ${id}`)
    }
  )
}

const deleteUser = (request, response) => {
  const id = parseInt(request.params.id)

  pool.query('DELETE FROM Users WHERE id = $1', [id], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`User deleted with ID: ${id}`)
  })
}

module.exports = {
  getUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
// ---
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
// --
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct,
// --
  getLocales,
  createLocales,
  updateLocales,
  deleteLocales,
// --
  getGeneros,
  createGeneros,
  updateGeneros,
  deleteGeneros,
// --
  getEmpleados,
  createEmpleados,
  updateEmpleados,
  deleteEmpleados,
// --
  getLocalesEmpleados,
  createLocalesEmpleados,
// --
  getLocalesProductos,
  createLocalesProductos,
// --
}
